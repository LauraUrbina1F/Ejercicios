class Main {
  public static void main(String[] args) {
    System.out.println("Hello world!");
    
      public static void main(String[] args) {
      //crea objeto Scanner para obtener la entrada de la ventana de comandos
      Scanner entrada = new Scanner (System.in);

      int numero1; //declaración de variable, primer número a sumar
      int numero2; //declaración de variable, segundo número a sumar
      int suma; //declaración de variable, suma de numero1 y numero2

      System.out.print("Escriba el primer entero: "); //indicador
      numero1 = entrada.nextInt(); //lee el primer número del usuario

      System.out.print("Escriba el segundo entero: "); //indicador
      numero2 = entrada.nextInt(); //lee el segundo número del usuario

      suma = numero1 + numero2;//suma los números, después almacena el total en suma

      System.out.printIn("La suma es " + suma); //muestra la suma
  }
}