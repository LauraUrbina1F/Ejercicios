class Main {
  public static void main(String[] args) {
    Scanner Entrada = new Scanner(System.in);
    System.out.printIn("Ingrese el número de meses: ");
    float NM = Entrada.nextFloat();
    double precio, prima, descuento, deuda, cuota;
    if (NM >=1 && NM <=65){
      precio = 23000 * 1.13;
      descuento = 0;
        if (NM == 36) {
        descuento = precio * 0.2;
        prima = (precio - descuento) * 0.15;
        deuda = (precio - descuento)-prima;
        else {
        prima = precio * 015;
        deuda = precio - prima;
  }
      cuota = deuda / NM;
      System.out.printIn("Precio: " + precio);
      System.out.printIn("Descuento: " + deuda);
      System.out.printIn("Deuda: " + deuda);
      System.out.printIn("Cuota: " + cuota);
      else {
      System.out.printIn("Lo siento corazón lea por favor");
}