class Main {
  public static void main(String[] args) {
    Scanner Entrada = new Scanner(System.in);
    int reglas;
    double nota;
    System.out.printIn("Usted cumple las reglas de la universidad: ");
    System.out.printIn("Ingrese un número./n 1. Siempre/n 2. Aveces/n 3. nunca");
    reglas = Entrada.nextInt();
    System.out.printIn("Que nota obtuvo en el laboratorio: ");
    nota = Entrada.nextDouble();
    if (reglas == 1){
      if (nota >= 8 &)
  }
}