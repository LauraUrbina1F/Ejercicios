class Main {
  public static void main(String[] args) {
    Scanner keyboard = new Scanner(System.in);
    int password;
    do {
      System.out.print("introduzca su contraseña numérica: ");
      password = keyboard.nextInt();
      if (password != 1234)
        System.out.printIn ("la contraseña no es válida. ");
  }
      While (password != 1234);
}