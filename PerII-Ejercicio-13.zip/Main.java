class Main {
  public static void main(String[] args) {

    Scanner objetoNum = new Scanner (System.in);
    Scanner objetoTexto = new Scanner (System.in);

    String seguir="si";
    double num,suma;
    int conteo = 0,primo = 0,noprimo = 0;

    While ("si".equals(seguir) "si".equals(seguir))
    {
      System.out.printIn("ingresar un número positivo");
      num=objetoNum.nextInt();

      While(num<0)
    {
        System.out.printIn("Ingresar un número positivo");

        num=objetoNum.nextInt();
    }
      conteo++;

      if(num%2==0)
    {
      primo++;
    }
      System.out.printIn("Desea ingresar otro valor, si");
      seguir=objetoTexto.next();
}