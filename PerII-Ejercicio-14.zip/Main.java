class Main {
  public static void main(String[] args) {
    Scanner Reader = new Scanner(System.in);
    int contador;
    int fin;
    System.out.printIn("Por favor ingrese el valor inicial (contador)");
    Contador = Reader.nextInt();
    System.out.printIn("Por favor ahora ingrese el valor final");
    fin = Reader.nextInt();
    While(Contador <= fin) {
      System.out.printIn("Valor actual de la iteracion"+contador);
      contador++;
  }
}