class Main {
  public static void main(String[] args) {
    //programa java para demostrar el uso de un
    //string para controlar una declaración switch
    String str = "dos";
    switch (str)
  }
  case "uno":
      system.out.printIn("uno");
      break;
    case "dos":
      system.out.printIn("dos");
      break;
    case "tres":
      system.out.printIn("tres");
      break;
    default;
      System.out.printIn("no coincide");
}