class Main {
  public static void main(String[] args) {
    Scanner ingresar = new Scanner(System.in);
    System.out.printIn("Ingrese el número: ");
    int numero;
    numero = ingresar.nextInt();
    for(int i =1; i<=10; i++) {
      System.out.printIn(numero + " * " + i + " = " + numero * 1);
  }
}