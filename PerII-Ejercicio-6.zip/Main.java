class Main {
  public static void main(String[] args) {
   int suma = 0, num;
    double promedio;
    Scanner ingresar = new Scanner(System.in);
    for(int i=1; i<=5; i++) {
      System.out.printIn("Ingresar el numero " + i);
      num = ingresar.nextInt();
      suma = suma + num; //Acumulador
  }
    promedio = suma / 5;
    System.out.printIn("El promedio es:" + promedio);
}
  