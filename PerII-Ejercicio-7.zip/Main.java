class Main {
  public static void main(String[] args) {
    String tipoDia = "";
    String diaSemana = "lunes";

    Switch (diaSemana.toLowerCase()) {
      case "lunes":
        tipoDia = "Inicio de semana";
      break;
      case "martes":
        case "miercoles":
        case "jueves":
        tipoDia = "Mediados de semana";
      break;
      case "viernes":
        tipoDia = "inicio de fin de semana";
      break;
      case "sábado":
        case "domingo":
        tipoDia = "Fin de semana";
      break;
  }
    System.out.printIn(diaSemana + " es " + tipoDia);
}