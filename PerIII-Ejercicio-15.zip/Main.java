class Main {
  public static void main(String[] args) {
    int fact=1, num, cont=1;
    Scanner entrada = new Scanner (System.in);
    System.out.printIn("Ingrese un número: ");
    num = entrada.nextInt();
    do {
      fact = fact*cont;
      cont = cont+1;
    } While (cont<=num);
    System.out.printIn("El factorial es: "+fact);
}