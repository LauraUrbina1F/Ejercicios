class Main {
  public static void main(String[] args) {
    int suma = 0, cant = 0, valor, promedio;
    Scanner entrada = new Scanner (System.in);
    do {
      System.out.printIn("Ingrese 0 para salir");
      System.out.printIn("Ingrese el valor");
      valor = entrada.nextInt();
      if(valor != 0) {
        suma = suma + valor;
        cant = cant + 1;
      }
   } While (valor != 0);
    if (cant !=0) {
      promedio = suma/cant;
      System.out.printIn("El promedio es: " + promedio);
   } else {
      System.out.printIn("No se ingresaron valores");
  }
}