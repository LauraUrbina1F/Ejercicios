class Main {
  public static void main(String[] args) {
    for (char c='a'; c<='z'; c++) {
      System.out.printIn("El caracter " + (int)c + "es: " + c);
    }
  }
}