class Main {
  public static void main(String[] args) {
    Scanner teclado = new Scanner (System.in);
    int i = 1; //contador del bucle que dara tantas vueltas como sea el exponente
    int potencia; //guarda el valor de la potencia
    int base;
    int calculo = 1;
    System.out.print("Introduzca el valor de la base: ");
    base = teclado.nextInt();
    System.out.print("Introduzca el valor del exponente: ");
    potencia = teclado.nextInt();
    While (i<=potencia) {
      calculo = calculo * base;
      i ++;
    }
    System.out.printIn("El resultado del calculo de la potencia es: " + calculo);
  }  
}