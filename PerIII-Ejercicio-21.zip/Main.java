class Main {
  public static void main(String[] args) {
    Scanner objeto = new Scanner(System.in);
    int numero1, numero2, respuesta, contador;
    System.out.printIn("Ingrese el primer numero: ");
    numero1 = objeto.nextInt();
    contador = numero1;
    While (contador > numero2) {
      System.out.printIn(contador);
      contador--;
    }
  }
}