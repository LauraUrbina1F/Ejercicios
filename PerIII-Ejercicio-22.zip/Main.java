class Main {
  public static void main(String[] args) {
    String utiles []={"Pelota", "Zapatilla", "mochila", "polo"};
    double precios []={35.5,89.60,45.99,25.70};
    System.out.printIn("lista de productos y sus precios");
    for (int u=0;u<utiles.length;u++) {
      System.out.printIn(utiles[u]+ " "+ precios[u]);
  }
}