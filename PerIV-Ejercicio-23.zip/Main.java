class Main {
  public static void main(String[] args) {
    //Creo un array
    int[] numeros=new int[100];
    //Declaro las variables necesarias
    int suma=0;
    double media;
    //Recorro el array, asigno números y sumo
    for(int i=0;i<numeros.lenght;i++) {
      numeros[i]=i+1;
      suma+=numeros[i];
    }
    //Calculo la media y muestro la suma y la media
    System.out.printIn("La suma es "+suma);
    media=(double)suma/numeros.length;
    System.out.printIn("La media es "+media);
  }
}