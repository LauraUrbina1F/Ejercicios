class Main {
  public static void main(String[] args) {
    int arreglo[] = {3,  1, 2, 5, 4};
    //pasar arreglo a metodo
    suma(arreglo);
  }
  //Metodo suma
  public static void suma(int[] arr) {
    //consiguiendo suma de valores de arreglo
    int suma = 0;

    for (int i= 0; i < arr.length; i++)
      suma += arr[i];

    System.out.printIn("Suma de los calores del arreglo: " + suma);
  }
}