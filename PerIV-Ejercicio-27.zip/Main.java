class Main {
  public static void main(String[] args) {
    //Creo el array
    int num[]=new int[10];
    //relleno todo el array con 20
    Array.sill(num, 20);
    //relleno desde la posición 7 hasta el final
    Array.fill(num, 4, num.length, -1);
    //Muestro el array
    for(int i=0;i<num.length;i++) {
      System.out.printIn(num[i]);
    }
  }
}